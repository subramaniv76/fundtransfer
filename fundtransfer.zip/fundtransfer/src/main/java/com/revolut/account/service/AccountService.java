package com.revolut.account.service;

import com.revolut.account.Dao.AccountDAO;
import com.revolut.account.pojo.Account;
import com.revolut.fundtransfer.currency.pojo.CurrencyRate;
import com.revolut.transaction.details.pojo.TransactionDetails;

public class AccountService {
	AccountDAO accountDAO = new AccountDAO();

	public int createAccount(Account account) {
		int status = accountDAO.createAccount(account);

		return status;
	}

	public Account getAccountDetails(String account) {
		Account accountdetails = accountDAO.getAccountDetails(account);
		return accountdetails;
	}

	public TransactionDetails getTransactionDetails(String transactionID) {
		TransactionDetails transactionDetails = accountDAO.getTransactionDetails(transactionID);
		return transactionDetails;
	}

	public void createTables() {
		accountDAO.createTables();
	}

	public void insertTransactionDetails(TransactionDetails td) {
		accountDAO.insertTransactionDetails(td);
	}

	public CurrencyRate getConversionRate(String sourceCurrencyCode, String destinationCurrencyCode) {
		return accountDAO.getConversionRate(sourceCurrencyCode, destinationCurrencyCode);
	}

	public int accountTransfer(String debitAmount, String debitAccountNumber, String creditAmount,
			String creditAccountNumber) {
		return accountDAO.accountTransfer(debitAmount, debitAccountNumber, creditAmount, creditAccountNumber);
	}
}
