package com.revolut.account.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.revolut.account.pojo.Account;
import com.revolut.fundtransfer.Dao.DataBaseConnection;
import com.revolut.fundtransfer.currency.pojo.CurrencyRate;
import com.revolut.transaction.details.pojo.TransactionDetails;

public class AccountDAO {

	Connection con = null;

	public int createAccount(Account account) {
		int insertStatus = 0;
		PreparedStatement st = null;

		String insertTable = "INSERT INTO ACCOUNT(ACCOUNT_NUMBER, ACCOUNT_NAME,ACCOUNT_TYPE,AMOUNT,CURRENCY) VALUES(?,?,?,?,?)";

		try {
			con = DataBaseConnection.getConnection();
			st = con.prepareStatement(insertTable);
			st.setString(1, account.getAccountNumber());
			st.setString(2, account.getAccountName());
			st.setString(3, account.getAccountType());
			st.setString(4, account.getAmount());
			st.setString(5, account.getCurrency());
			insertStatus = st.executeUpdate();
			con.commit();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			st = null;
		}
		return insertStatus;
	}

	public Account getAccountDetails(String accountNumber) {
		String accountNo = null;
		String accountName = null;
		String accountType = null;
		String amount = null;
		Account account = null;
		String currency = null;
		PreparedStatement st = null;
		try {
			con = DataBaseConnection.getConnection();
			st = con.prepareStatement(
					"Select ACCOUNT_NUMBER,ACCOUNT_NAME,ACCOUNT_TYPE,AMOUNT,CURRENCY from ACCOUNT where ACCOUNT_NUMBER=?");
			st.setString(1, accountNumber);
			ResultSet rs = st.executeQuery();
			while (rs.next()) {
				accountNo = rs.getString("ACCOUNT_NUMBER");
				accountName = rs.getString("ACCOUNT_NAME");
				accountType = rs.getString("ACCOUNT_TYPE");
				amount = rs.getString("AMOUNT");
				currency = rs.getString("CURRENCY");
			}
			account = new Account();
			account.setAccountName(accountName);
			account.setAccountNumber(accountNo);
			account.setAccountType(accountType);
			account.setAmount(amount);
			account.setCurrency(currency);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			st = null;
			accountNo = null;
			accountName = null;
			accountType = null;
			amount = null;
			currency = null;
		}

		return account;
	}

	public TransactionDetails getTransactionDetails(String transactionID) {
		String fromAccount = null;
		String toAccount = null;
		String transaction_id = null;
		String amount = null;
		String status = null;
		TransactionDetails transactionDetails = null;
		PreparedStatement st = null;
		try {
			con = DataBaseConnection.getConnection();
			st = con.prepareStatement(
					"Select TRANSACTION_ID,FROM_ACCOUNT,TO_ACCOUNT,SOURCE_AMOUNT,STATUS from TRANSACTION_DETAILS where TRANSACTION_ID=?");
			st.setString(1, transactionID);
			ResultSet rs = st.executeQuery();
			while (rs.next()) {
				transaction_id = rs.getString("TRANSACTION_ID");
				fromAccount = rs.getString("FROM_ACCOUNT");
				toAccount = rs.getString("TO_ACCOUNT");
				amount = rs.getString("SOURCE_AMOUNT");
				status = rs.getString("STATUS");
			}
			transactionDetails = new TransactionDetails();
			transactionDetails.setFromAccount(fromAccount);
			transactionDetails.setToAccount(toAccount);
			transactionDetails.setStatus(status);
			transactionDetails.setTransactionId(transaction_id);
			transactionDetails.setAmount(amount);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			st = null;
			fromAccount = null;
			toAccount = null;
			status = null;
			amount = null;
			transaction_id = null;
		}

		return transactionDetails;
	}

	public void createTables() {
		String createTable = "CREATE TABLE ACCOUNT(ACCOUNT_NUMBER INT PRIMARY KEY ,ACCOUNT_NAME VARCHAR(150),ACCOUNT_TYPE VARCHAR(150),AMOUNT VARCHAR(150),CURRENCY VARCHAR(150));";
		String createCurrencyTable = "CREATE TABLE CURRENCY_RATE(SOURCE_CURRENCY_CODE VARCHAR(150),DESTINATION_CURRENCY_CODE VARCHAR(150) ,RATE VARCHAR(150))";
		String createTransactionTable = "CREATE TABLE TRANSACTION_DETAILS(TRANSACTION_ID VARCHAR(150) ,FROM_ACCOUNT VARCHAR(150),TO_ACCOUNT VARCHAR(150),SOURCE_AMOUNT VARCHAR(150),STATUS VARCHAR(150))";
		Statement st;
		try {
			con = DataBaseConnection.getConnection();
			st = con.createStatement();
			st.executeUpdate(createTable);
			st.executeUpdate(createCurrencyTable);
			st.executeUpdate(createTransactionTable);
			insertCurrencyRateTable();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			st = null;
		}

	}

	@SuppressWarnings("serial")
	public void insertCurrencyRateTable() {
		String insertCurrencyRate = "INSERT INTO CURRENCY_RATE(SOURCE_CURRENCY_CODE,DESTINATION_CURRENCY_CODE, RATE) VALUES(?,?,?)";
		PreparedStatement st;
		try {
			con = DataBaseConnection.getConnection();
			st = con.prepareStatement(insertCurrencyRate);
			// for example inserted two currencies
			List<CurrencyRate> list = new ArrayList<CurrencyRate>() {
				{
					add(new CurrencyRate("USD", "GBP", "0.79"));
					add(new CurrencyRate("GBP", "USD", "1.26"));
				}
			};
			for (CurrencyRate cr : list) {
				st.setString(1, cr.getSourceCurrencyCode());
				st.setString(2, cr.getDestinationCurrencyCode());
				st.setString(3, cr.getRate());
				st.executeUpdate();
			}
			con.commit();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			st = null;
		}

	}

	public void insertTransactionDetails(TransactionDetails td) {
		String insertCurrencyRate = "INSERT INTO TRANSACTION_DETAILS(TRANSACTION_ID,FROM_ACCOUNT,TO_ACCOUNT,SOURCE_AMOUNT,STATUS) VALUES(?,?,?,?,?)";
		PreparedStatement st;
		try {
			con = DataBaseConnection.getConnection();
			st = con.prepareStatement(insertCurrencyRate);

			st.setString(1, td.getTransactionId());
			st.setString(2, td.getFromAccount());
			st.setString(3, td.getToAccount());
			st.setString(4, td.getAmount());
			st.setString(5, td.getStatus());
			st.executeUpdate();

			con.commit();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			st = null;
		}

	}

	public CurrencyRate getConversionRate(String sourceCurrencyCode, String destinationCurrencyCode) {

		String source_currency_code = null;
		String destination_currency_code = null;
		String rate = null;
		CurrencyRate currencyRate = null;
		PreparedStatement st = null;
		try {
			con = DataBaseConnection.getConnection();
			st = con.prepareStatement(
					"Select SOURCE_CURRENCY_CODE,DESTINATION_CURRENCY_CODE,RATE from CURRENCY_RATE where SOURCE_CURRENCY_CODE=? and DESTINATION_CURRENCY_CODE=?");
			st.setString(1, sourceCurrencyCode);
			st.setString(2, destinationCurrencyCode);
			ResultSet rs = st.executeQuery();
			while (rs.next()) {
				source_currency_code = rs.getString("SOURCE_CURRENCY_CODE");
				destination_currency_code = rs.getString("DESTINATION_CURRENCY_CODE");
				rate = rs.getString("RATE");
			}
			currencyRate = new CurrencyRate();
			currencyRate.setSourceCurrencyCode(source_currency_code);
			currencyRate.setDestinationCurrencyCode(destination_currency_code);
			currencyRate.setRate(rate);

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			st = null;
			rate = null;
			source_currency_code = null;
			destination_currency_code = null;

		}

		return currencyRate;
	}

	public int accountTransfer(String debitAmount, String debitAccountNumber, String creditAmount,
			String creditAccountNumber) {
		int debitUpdateStatus = 0;
		int creditUpdateStatus = 0;
		PreparedStatement st = null;

		String updateTable = "UPDATE ACCOUNT SET AMOUNT=? WHERE ACCOUNT_NUMBER=?";

		try {
			con = DataBaseConnection.getConnection();
			st = con.prepareStatement(updateTable);
			st.setString(1, debitAmount);
			st.setString(2, debitAccountNumber);
			debitUpdateStatus = st.executeUpdate();
			if (debitUpdateStatus >= 1) {
				st = con.prepareStatement(updateTable);
				st.setString(1, creditAmount);
				st.setString(2, creditAccountNumber);
				creditUpdateStatus = st.executeUpdate();
			}

			if (creditUpdateStatus > 1) {
				con.commit();
			} else {
				con.rollback();
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			st = null;
		}
		return creditUpdateStatus;
	}
}
