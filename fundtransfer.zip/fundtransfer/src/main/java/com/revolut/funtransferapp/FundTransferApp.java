package com.revolut.funtransferapp;

import java.net.URI;

import javax.ws.rs.core.UriBuilder;

import org.glassfish.jersey.jdkhttp.JdkHttpServerFactory;
import org.glassfish.jersey.server.ResourceConfig;

import com.revolut.fundtranfer.ws.FundTransfer;
import com.revolut.fundtransfer.constants.DataBasePreRequest;



public class FundTransferApp 
{
	private final static int port = 8098;
	private final static String host="http://localhost/";
    public static void main( String[] args )
    {
    	URI baseUri = UriBuilder.fromUri(host).port(port).build();
    	ResourceConfig config = new ResourceConfig(FundTransfer.class);
    	JdkHttpServerFactory.createHttpServer(baseUri, config);
    	DataBasePreRequest.createTables();
    }
}
