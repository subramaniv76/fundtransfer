package com.revolut.fundtranfer.ws;

import java.io.IOException;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.revolut.account.pojo.Account;
import com.revolut.account.pojo.AccountResponse;
import com.revolut.account.service.AccountService;
import com.revolut.fundtransfer.exception.AccountNotFoundException;
import com.revolut.fundtransfer.exception.CurrencyNotSupportedException;
import com.revolut.fundtransfer.exception.InSufficientBalanceException;
import com.revolut.fundtransfer.exception.InvalidInputException;
import com.revolut.fundtransfer.request.pojo.FundTransferRequest;
import com.revolut.fundtransfer.response.pojo.FundTransferResponse;
import com.revolut.fundtransfer.service.FundTransferService;
import com.revolut.transaction.details.pojo.TransactionDetails;

@Path("/v1")
public class FundTransfer {
	ObjectMapper mapper = new ObjectMapper();

	@POST
	@Path("/fundtransfer")
	@Produces(MediaType.APPLICATION_JSON)
	public Response fundTransfer(String json) {
		ObjectMapper mapper = new ObjectMapper();
		FundTransferRequest fundTransferRequest = null;
		FundTransferService fundTransferService = null;
		FundTransferResponse fundTransferResponse = null;
		try {
			fundTransferRequest = mapper.readValue(json, FundTransferRequest.class);
			try {
				ValidateInput(fundTransferRequest);
			} catch (InvalidInputException e1) {
				return Response.ok(e1.getMessage()).build();
			}
			fundTransferService = new FundTransferService();
			try {
				fundTransferResponse = fundTransferService.transferFund(fundTransferRequest);
			} catch (InSufficientBalanceException e) {
				return Response.ok(e.getMessage()).build();
			} catch (AccountNotFoundException e) {
				return Response.ok(e.getMessage()).build();
			} catch (CurrencyNotSupportedException e) {
				return Response.ok(e.getMessage()).build();
			}

		} catch (JsonParseException e) {
			return Response.ok("Error While Parsing input Please check your input data format").build();
		} catch (JsonMappingException e) {
			return Response.ok("Error While Parsing input Please check your input data format").build();
		} catch (IOException e) {
			return Response.ok("Error While Parsing input Please check your input data format").build();
		} catch (Exception e) {
			return Response.ok("Error occured in fundtransfer service").build();
		} finally {
			fundTransferService = null;
		}
		return Response.status(Response.Status.OK).entity(fundTransferResponse).build();
	}

	@POST
	@Path("/createaccount")
	@Produces(MediaType.APPLICATION_JSON)
	public Response createAccount(String json) {
		AccountService as = new AccountService();
		Account account = null;
		AccountResponse ar = null;
		try {
			ar = new AccountResponse();
			account = mapper.readValue(json, Account.class);
			ar.setAccountNumber(account.getAccountNumber());
			if (account.getAccountNumber() == null || account.getAccountNumber().length() <= 0) {

				ar.setStatus("Account Creation Failed Due to Invalid Account Number");
				return Response.status(Response.Status.OK).entity(ar).build();
			}
			if (account.getAmount() == null || account.getAmount().length() <= 0
					|| !account.getAmount().matches("[0-9]+([,.][0-9]{1,2})?")) {
				ar.setStatus("Account Creation Failed Due to Invalid Amount");
				return Response.status(Response.Status.OK).entity(ar).build();
			}
			if (account.getAccountType() == null || account.getAccountType().length() <= 0) {
				ar.setStatus("Account Creation Failed Due to Invalid Account Type");
				return Response.status(Response.Status.OK).entity(ar).build();
			}
			if (account.getCurrency() == null || account.getCurrency().length() <= 0) {
				ar.setStatus("Account Creation Failed Due to Invalid Currency");
				return Response.status(Response.Status.OK).entity(ar).build();
			}
			int status = as.createAccount(account);
			if (status > 0) {
				ar.setStatus("Created Successfully");
			} else {
				ar.setStatus("Account Creation Failed due to General Error");
			}
		} catch (JsonParseException e) {
			ar.setStatus("Invalid input format");
		} catch (JsonMappingException e) {
			ar.setStatus("Invalid input format");
		} catch (IOException e) {
			ar.setStatus("Invalid input format");
		} finally {
			as = null;
		}
		return Response.status(Response.Status.OK).entity(ar).build();
	}

	@GET
	@Path("/getaccount")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getAccount(String json) {
		Account account = null;
		AccountService as = new AccountService();

		try {
			account = mapper.readValue(json, Account.class);
			account = as.getAccountDetails(account.getAccountNumber());
			if (account.getAccountNumber() == null || account.getAccountNumber().length() <= 0) {
				return Response.ok("Invalid Account Number").build();
			}
		} catch (JsonParseException e) {
			return Response.status(Response.Status.OK).entity("Invalid Input Format").build();
		} catch (JsonMappingException e) {
			return Response.status(Response.Status.OK).entity("Invalid Input Format").build();
		} catch (IOException e) {
			return Response.status(Response.Status.OK).entity("Invalid Input Format").build();
		} catch (Exception e) {
			return Response.status(Response.Status.OK).entity("Error Occured in getaccount service").build();
		}

		finally {
			as = null;
		}

		return Response.status(Response.Status.OK).entity(account).build();
	}

	@GET
	@Path("/transactionenquiry")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getTransaction(String json) {
		TransactionDetails transactionDetails = null;
		AccountService as = new AccountService();

		try {
			transactionDetails = mapper.readValue(json, TransactionDetails.class);
			transactionDetails = as.getTransactionDetails(transactionDetails.getTransactionId());
			if (transactionDetails.getTransactionId() == null || transactionDetails.getTransactionId().length() <= 0) {
				return Response.ok("Invalid Transaction ID").build();
			}
		} catch (JsonParseException e) {
			return Response.status(Response.Status.OK).entity("Invalid Input Format").build();
		} catch (JsonMappingException e) {
			return Response.status(Response.Status.OK).entity("Invalid Input Format").build();
		} catch (IOException e) {
			return Response.status(Response.Status.OK).entity("Invalid Input Format").build();
		} catch (Exception e) {
			return Response.status(Response.Status.OK).entity("Error Occured in transactionenquiry service").build();
		} finally {
			as = null;
		}

		return Response.status(Response.Status.OK).entity(transactionDetails).build();
	}

	private void ValidateInput(FundTransferRequest fundTransferRequest) throws InvalidInputException {
		if (fundTransferRequest.getFromAccountNumber() == null) {
			throw new InvalidInputException("Invalid from Account Number");
		}

		if (fundTransferRequest.getToAccountNumber() == null) {
			throw new InvalidInputException("Invalid from Account Number");
		}

		if (fundTransferRequest.getAmount() == null
				&& fundTransferRequest.getAmount().matches("[0-9]+([,.][0-9]{1,2})?")) {
			throw new InvalidInputException("Invalid amount");
		}

	}

}