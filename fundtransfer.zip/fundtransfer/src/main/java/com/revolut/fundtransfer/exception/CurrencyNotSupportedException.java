package com.revolut.fundtransfer.exception;

@SuppressWarnings("serial")
public class CurrencyNotSupportedException extends Exception {

	
	public CurrencyNotSupportedException(String message)
	{
		super(message);
	}


}
