package com.revolut.fundtransfer.exception;

public class InSufficientBalanceException  extends Exception{
	
	public InSufficientBalanceException(String message)
	{
		super(message);
	}

}
