package com.revolut.fundtransfer.constants;

import com.revolut.account.Dao.AccountDAO;

public class DataBasePreRequest {
	
	public static void createTables()
	{
		AccountDAO adao= new AccountDAO();
		
		adao.createTables();
	}

}
