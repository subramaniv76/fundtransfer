package com.revolut.fundtransfer.Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.revolut.fundtransfer.constants.DataBaseConstants;

public class DataBaseConnection {

	public static Connection getConnection() {

		Connection con = null;

		try {
			con = DriverManager.getConnection(DataBaseConstants.DB_URL);

		} catch (Exception ex) {

		}

		return con;
	}
}
