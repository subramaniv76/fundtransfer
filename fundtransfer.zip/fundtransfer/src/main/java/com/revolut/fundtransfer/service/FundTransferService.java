package com.revolut.fundtransfer.service;

import java.math.BigDecimal;
import java.util.Random;

import com.revolut.account.pojo.Account;
import com.revolut.account.service.AccountService;
import com.revolut.fundtransfer.currency.pojo.CurrencyRate;
import com.revolut.fundtransfer.exception.AccountNotFoundException;
import com.revolut.fundtransfer.exception.CurrencyNotSupportedException;
import com.revolut.fundtransfer.exception.InSufficientBalanceException;
import com.revolut.fundtransfer.request.pojo.FundTransferRequest;
import com.revolut.fundtransfer.response.pojo.FundTransferResponse;
import com.revolut.transaction.details.pojo.TransactionDetails;

public class FundTransferService {

	AccountService accountService = null;

	public FundTransferResponse transferFund(FundTransferRequest fundTransferRequest)
			throws InSufficientBalanceException, AccountNotFoundException, CurrencyNotSupportedException, Exception {
		FundTransferResponse fundTransferResponse = new FundTransferResponse();

		accountService = new AccountService();
		try {

			Account fromAccountDetails = accountService.getAccountDetails(fundTransferRequest.getFromAccountNumber());

			Account toAccountDetails = accountService.getAccountDetails(fundTransferRequest.getToAccountNumber());

			if (fromAccountDetails.getAccountNumber() == null) {
				throw new AccountNotFoundException(
						"Invalid from account Number " + fundTransferRequest.getFromAccountNumber());
			}
			if (toAccountDetails.getAccountNumber() == null) {
				throw new AccountNotFoundException(
						"Invalid to account Number " + fundTransferRequest.getToAccountNumber());
			}

			BigDecimal totalFromAmount = new BigDecimal(fromAccountDetails.getAmount());

			BigDecimal totalToAmount = new BigDecimal(toAccountDetails.getAmount());

			BigDecimal debitAmount = new BigDecimal(fundTransferRequest.getAmount());

			BigDecimal creditAmount = new BigDecimal(fundTransferRequest.getAmount());

			if (totalFromAmount.compareTo(debitAmount) < 1) {
				throw new InSufficientBalanceException(
						"InSuffient Balance in  account " + fundTransferRequest.getFromAccountNumber());
			}

			if (!fromAccountDetails.getCurrency().equalsIgnoreCase(toAccountDetails.getCurrency())) {
				CurrencyRate currencyRate = accountService.getConversionRate(fromAccountDetails.getCurrency(),
						toAccountDetails.getCurrency());
				if (currencyRate.getRate() == null || currencyRate.getRate().length() <= 0) {
					throw new CurrencyNotSupportedException("Currency not supported");
				}
				creditAmount = convertToCurrency(debitAmount, new BigDecimal(currencyRate.getRate()));
			}

			int status = accountService.accountTransfer(debitRule(debitAmount, totalFromAmount).toPlainString(),
					fundTransferRequest.getFromAccountNumber(), creditRule(creditAmount, totalToAmount).toPlainString(),
					fundTransferRequest.getToAccountNumber());
			fundTransferResponse.setAmount(fundTransferRequest.getAmount());
			TransactionDetails td = new TransactionDetails();
			td.setTransactionId(generateRandomDigits(8)+"");
			fundTransferResponse.setTransactionId(td.getTransactionId());
			if (status > 0) {
				fundTransferResponse.setTransferStatus("Transaction Success");
				td.setFromAccount(fundTransferRequest.getFromAccountNumber());
				td.setToAccount(fundTransferRequest.getToAccountNumber());
				td.setAmount(fundTransferRequest.getAmount());
				td.setStatus("SUCCESS");
				accountService.insertTransactionDetails(td);

			} else {
				fundTransferResponse.setTransferStatus("Transaction Failed");
				td.setFromAccount(fundTransferRequest.getFromAccountNumber());
				td.setToAccount(fundTransferRequest.getToAccountNumber());
				td.setAmount(fundTransferRequest.getAmount());
				td.setStatus("FAILURE");
				accountService.insertTransactionDetails(td);
			}
		} catch (Exception e) {
			throw e;
		} finally {
			accountService = null;
		}
		return fundTransferResponse;

	}

	private BigDecimal debitRule(BigDecimal transactionAmount, BigDecimal debitorAmount) {
		BigDecimal result = debitorAmount.subtract(transactionAmount);
		result = result.setScale(2, BigDecimal.ROUND_HALF_UP);
		return result;
	}

	private BigDecimal creditRule(BigDecimal transactionAmount, BigDecimal creditorAmount) {
		BigDecimal result = creditorAmount.add(transactionAmount);
		result = result.setScale(2, BigDecimal.ROUND_HALF_UP);
		return result;
	}

	private BigDecimal convertToCurrency(BigDecimal sourceAmount, BigDecimal rate) {
		BigDecimal result;
		result = sourceAmount.multiply(rate);
		result = result.setScale(2, BigDecimal.ROUND_HALF_UP);
		return result;
	}
	private  int generateRandomDigits(int n) {
	    int m = (int) Math.pow(10, n - 1);
	    return m + new Random().nextInt(9 * m);
	}

}
