package com.revolut.fundtransfer.currency.pojo;

public class CurrencyRate {

	private String sourceCurrencyCode;
	private String destinationCurrencyCode;
	private String Rate;

	public CurrencyRate() {

	}

	public String getSourceCurrencyCode() {
		return sourceCurrencyCode;
	}

	public void setSourceCurrencyCode(String sourceCurrencyCode) {
		this.sourceCurrencyCode = sourceCurrencyCode;
	}

	public String getDestinationCurrencyCode() {
		return destinationCurrencyCode;
	}

	public void setDestinationCurrencyCode(String destinationCurrencyCode) {
		this.destinationCurrencyCode = destinationCurrencyCode;
	}

	public CurrencyRate(String sourceCurrencyCode, String destinationCurrencyCode, String rate) {
		this.sourceCurrencyCode = sourceCurrencyCode;
		this.destinationCurrencyCode = destinationCurrencyCode;
		this.Rate = rate;
	}

	public String getRate() {
		return Rate;
	}

	public void setRate(String rate) {
		Rate = rate;
	}

}
