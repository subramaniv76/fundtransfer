package com.revolut.fundtransfer.constants;

public class DataBaseConstants {

	public static String DB_URL = "jdbc:h2:mem:db1;DB_CLOSE_DELAY=-1";
	//public static String url = "jdbc:h2:tcp://localhost:9092/testdb";
	//public static String user = "sa";
	//public static String passwd = "s$cret";

}
